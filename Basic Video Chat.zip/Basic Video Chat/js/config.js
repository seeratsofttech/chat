/* eslint-disable no-unused-vars */
// Make a copy of this file and save it as config.js (in the js directory).

// Set this to the base URL of your sample server, such as 'https://your-app-name.herokuapp.com'.
// Do not include the trailing slash. See the README for more information:

var SAMPLE_SERVER_BASE_URL = 'https://opentok-web-samples-backend.herokuapp.com';

// OR, if you have not set up a web server that runs the learning-opentok-php code,
// set these values to OpenTok API key, a valid session ID, and a token for the session.
// For test purposes, you can obtain these from https://tokbox.com/account.

var API_KEY = '3924694';
var SESSION_ID = '2_MX40NjgyNDMwNH5-MTU5Mzg3MDAyNTg2MH5OdkU2M3U2UHRDRVRUL2hLK3BWRFkvakl-UH4';
var TOKEN = 'T1==cGFydG5lcl9pZD00NjgyNDMwNCZzaWc9ZDE0YTY2MzM2OGE1ZWI0ZmY5MDA5MmVkODA4MGM2OTJjODQ5OGM1ZTpzZXNzaW9uX2lkPTJfTVg0ME5qZ3lORE13Tkg1LU1UVTVNemczTURBeU5UZzJNSDVPZGtVMk0zVTJVSFJEUlZSVUwyaExLM0JXUkZrdmFrbC1VSDQmY3JlYXRlX3RpbWU9MTU5Mzg3MDEwMyZub25jZT0wLjE1NTUwNjg5NjQ3NDMxNTM3JnJvbGU9bW9kZXJhdG9yJmV4cGlyZV90aW1lPTE1OTY0NjIwOTImaW5pdGlhbF9sYXlvdXRfY2xhc3NfbGlzdD0=';
